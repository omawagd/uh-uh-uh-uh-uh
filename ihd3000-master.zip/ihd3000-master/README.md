# ihd3000
Patch Intel HD 3000 for VRAM allocation on MacOSX - www.firstplato.com - <a href="https://github.com/ipang-dwi/ihd3000/releases">Release / Download Here</a>

<img src="https://raw.githubusercontent.com/ipang-dwi/ihd3000/master/ok.png"/>

Tested on Asus X45C - MacOS High Sierra 10.13.6 with custom :
- 1GB VRAM
- 1.5GB VRAM
- 2GB VRAM

NB : DVMT pre-allocated 512MB

<a href="https://github.com/ipang-dwi/ihd3000/releases">Release / Download Here</a>

Just select which one of patch is suitable for you. I just recommend 1GB for minimal 4GB RAM, 1.5GB for Minimal 6GB RAM and 2GB for minimal 8GB RAM. Install it with your favorite kext injector, I would prefer use Kext Utility.

For other DVMT, please feel free to reach me, coz I didn't have original file kext from High Sierra. Just share your original AppleIntelSNBGraphicsFB.kext to me. May I can patch it for you.

> Crafted with love by ipang-dwi - www.firstplato.com - member of Forum Hackintosh Indonesia. Happy hackintoshing.
