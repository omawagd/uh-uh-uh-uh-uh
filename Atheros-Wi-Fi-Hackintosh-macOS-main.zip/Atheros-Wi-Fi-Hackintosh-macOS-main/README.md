# Atheros--Wi-Fi-mac
注意，他仅仅适用于Big Sur及其以下版本，Monterey还暂不支持、

## 使用方法
将HS80211Family.kext以及你对应版本的AirPortAtheros40放入EFI的kext中，然后在config中加载这两个驱动，HS80211Family.kext在AirPortAtheros40前面
